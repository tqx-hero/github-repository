#include "/home/tqx/net/wrapper/sockwrapper.h"
#include "/home/tqx/net/thread-pool/thread-pool.h"
#include "./function/header/http_handler.h"
#include <fcntl.h>
#include <sys/syscall.h>
#define MAX_THREAD_SIZE 20
#define SERVER_PORT 9000
#define EVENT_BUFFER_SIZE 1024

/**
 * 优化服务器，将每个套接字与需要处理的业务函数绑定
 * 当事件触发时，根据不同事件进行相关处理，这就是反应堆模式
 */
typedef struct epoll_event event_type;
typedef struct sockaddr sock_addr_type;

// 反应堆的文件描述符与函数处理绑定的结构体
typedef struct
{
	int cur_fd;
	func_type func_handler;
	void *arg;
} reactor_t;
// 各事件触发后回调函数的参数
typedef struct
{
	int epfd;
	int con_fd;
	uint16_t cli_port;
	char cli_ip[INET_ADDRSTRLEN];
	pthread_pool_t *thread_pool;
	reactor_t *reactor;
} con_sock_t;

con_sock_t *malloc_consock_t(const con_sock_t *params);
reactor_t *malloc_reactor_t(int con_fd, func_type func_handler, void *arg);
void *reactor_listen(void *arg);
void *deal_with_socket(void *);
int main()
{
	// 创建监听套接字,设置为非阻塞
	int lfd = Socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK, 0);
	// 设置套接字端口、地址复用
	int opt = 1;
	setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(int));
	setsockopt(lfd, SOL_SOCKET, SO_REUSEPORT, &opt, sizeof(int));
	// 绑定
	struct sockaddr_in server_addr;
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(SERVER_PORT);
	server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	Bind(lfd, (sock_addr_type *)&server_addr, sizeof(server_addr));
	// 使监听套接字属性由主动连接变为被动链接
	Listen(lfd, 0);
	// 创建线程池，用线程池来处理连接的各种业务
	pthread_pool_t *pool = pthread_pool_create(MAX_THREAD_SIZE);
	if (!pool)
		exit(-1);
	// 创建epoll实例
	int epfd = Epoll_create(1);
	// 绑定套接字的要监听的事件
	event_type ep_event;
	ep_event.events = EPOLLIN; // 可以用或运算进行添加 | EPOLLOUT
	// 创建反应堆的事件驱动结构体
	con_sock_t temp;
	temp.epfd = epfd;
	temp.con_fd = lfd;
	temp.thread_pool = pool;
	con_sock_t *sct = malloc_consock_t(&temp);
	if (!sct)
	{
		close(lfd);
		return -1;
	}
	reactor_t *reactor = malloc_reactor_t(lfd, reactor_listen, (void *)sct);
	if (!reactor)
	{
		close(lfd);
		return -1;
	}
	// 将epoll监听事件之前绑定的fd切换为绑定结构体指针
	ep_event.data.ptr = (void *)reactor;
	Epoll_ctl(epfd, EPOLL_CTL_ADD, lfd, &ep_event);
	// 内核监听事件
	event_type event_buffer[EVENT_BUFFER_SIZE];
	while (1)
	{
		// 判断一下是否是被信号中断的，如果是
		int event_count;
		while (((event_count = epoll_wait(epfd, event_buffer, EVENT_BUFFER_SIZE, -1)) == -1 && errno == EINTR) || event_count == 0)
			;
		for (int i = 0; i < event_count; i++)
		{
			event_type event = event_buffer[i];
			// 拿到事件的反应堆结构体
			reactor_t *cur_reactor = (reactor_t *)event.data.ptr;
			// 调用反应堆中绑定的相关函数
			cur_reactor->func_handler(cur_reactor->arg);
		}
	}
	pthread_pool_destory(pool, 1);
	free(sct);
	free(reactor);
	close(lfd);
	return 0;
}
// 申请套接字连接信息的结构体
con_sock_t *malloc_consock_t(const con_sock_t *params)
{
	con_sock_t *cst = malloc(sizeof(con_sock_t));
	if (!cst)
	{
		perror("malloc con_sock_t error");
		return NULL;
	}
	cst->epfd = params->epfd;
	cst->con_fd = params->con_fd;
	cst->cli_port = params->cli_port;
	cst->thread_pool = params->thread_pool;
	memcpy(cst->cli_ip, params->cli_ip, INET_ADDRSTRLEN);
	return cst;
}
// 申请反应堆的结构体
reactor_t *malloc_reactor_t(int con_fd, func_type func_handler, void *arg)
{
	reactor_t *reactor = malloc(sizeof(reactor_t));
	if (!reactor)
	{
		perror("malloc reactor  error");
		free(reactor);
		return NULL;
	}
	// 设置事件驱动的函数与参数
	reactor->cur_fd = con_fd;
	reactor->func_handler = func_handler;
	reactor->arg = arg;
	return reactor;
}
// 连接套接字的处理函数
void *reactor_connection(void *arg)
{
	con_sock_t *cskt = (void *)arg;
	pthread_pool_submit(((con_sock_t *)arg)->thread_pool, deal_with_socket, arg);
	return NULL;
}

// 反应堆的连接处理函数
void *reactor_listen(void *arg)
{
	con_sock_t *cskt = (void *)arg;
	int epfd = cskt->epfd, lfd = cskt->con_fd;
	con_sock_t temp;
	temp.thread_pool = cskt->thread_pool;
	// 如果是监听套接字，那就accept连接，并将新的
	// 连接套接字注册到epoll红黑树结构中监听
	struct sockaddr_in cli_addr;
	socklen_t stk_len = sizeof(cli_addr);
	int con_fd = Accept(lfd, (sock_addr_type *)&cli_addr, &stk_len);
	// 设置新连接的套接字为非阻塞模式
	int flags = fcntl(con_fd, F_GETFL, 0);
	fcntl(con_fd, F_SETFL, flags | O_NONBLOCK);
	get_client_info_ipv4(&cli_addr, temp.cli_ip, &temp.cli_port);
	printf("[%s:%d]已上线!\n", temp.cli_ip, temp.cli_port);
	temp.epfd = epfd;
	temp.con_fd = con_fd;
	// 设置连接套接字的反应堆结构体
	con_sock_t *sct = malloc_consock_t(&temp);
	if (!sct)
	{
		close(con_fd);
		return (void *)(long)-1;
	}
	reactor_t *reactor = malloc_reactor_t(con_fd, reactor_connection, (void *)sct);
	if (!reactor)
	{
		close(con_fd);
		return (void *)(long)-1;
	}
	sct->reactor = reactor;
	event_type ep_event;
	// 将已连接的socket注册监听事件
	// 设置事件触发为边沿触发
	// 注意：当监听写事件时，必须设置为边沿触发，以免不必要的状态切换
	ep_event.events = EPOLLIN | EPOLLET; // | EPOLLOUT;
	// 将epoll监听事件之前绑定的fd切换为绑定结构体指针
	ep_event.data.ptr = (void *)reactor;
	Epoll_ctl(epfd, EPOLL_CTL_ADD, con_fd, &ep_event);
	return (void *)(long)0;
}


// 需要修改arg参数为一个结构体：结构体分别存放当前套接字cur_fd与epoll根节点的描述符epfd
void *deal_with_socket(void *arg)
{
	con_sock_t *con_sock = (con_sock_t *)arg;
	if (!con_sock)
	{
		perror("con_sock_t* format error");
		return NULL;
	}
	int epfd = con_sock->epfd, cur_fd = con_sock->con_fd;
	char *cli_ip = con_sock->cli_ip;
	uint16_t cli_port = con_sock->cli_port;
	char recv_buffer[MESSAGE_BUFFER_SIZE + 1];
	// 获取线程的tid
	// pid_t tid = syscall(SYS_gettid);
	while (1)
	{
		int r_len = Read(cur_fd, recv_buffer, MESSAGE_BUFFER_SIZE);
		if (r_len == 0)
		{
			printf("[%s:%d]已下线!\n", cli_ip, cli_port);
			goto return_func;
		}
		if (r_len == -1)
		{
			// 由于设置了非阻塞，read可能读不到数据返回-1，此时需要判断
			// 是否为正常读不到数据还是异常
			if (!(errno == EAGAIN || errno == EWOULDBLOCK))
				// 如果是非正常读取，将该socket关闭，从epoll结构中删除
				perror("read error");
			else
				cur_fd = -1;
			goto return_func;
		}
		// recv_buffer[r_len] =0;
		// printf("[%s:%d]:%s\n",cli_ip,cli_port,recv_buffer);
		// 解析http请求，发送相关的资源
		char error_buf[512];
		if (parse_http_request(cur_fd, recv_buffer, r_len, error_buf) == -1)
			printf("error:%s\n", error_buf);
	}
return_func:
	if (cur_fd >= 0)
	{
		// 需要将这个socket从epoll红黑树中去除
		// 下线断开连接
		Epoll_ctl(epfd, EPOLL_CTL_DEL, cur_fd, NULL);
		// 释放资源
		free(con_sock->reactor);
		con_sock->reactor = NULL;
		free(con_sock);
		close(cur_fd);
	}
	return NULL;
}
